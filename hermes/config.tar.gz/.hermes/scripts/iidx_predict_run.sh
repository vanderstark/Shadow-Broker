#!/bin/bash
# /opt/data/iidx-predict/scripts/run_pipeline.sh
# Jalankan pipeline IIDX-Predict otomatis tiap jadwal
set -euo pipefail

cd /opt/data/iidx-predict
source .venv/bin/activate
PYTHONPATH=/opt/data/iidx-predict/src python3 src/pipeline/iidx_predict_pipeline.py
echo "=== Pipeline finish @ $(date -u) ==="