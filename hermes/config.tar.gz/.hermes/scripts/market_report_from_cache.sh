#!/bin/bash
# Wrapper: generate market report from cached data (FAST, <5s)
# Jalankan via cron 3x/hari: 08:00, 16:30, 20:00 WIB
set -e
cd /opt/data/market-cache
source .venv/bin/activate
python3 report_from_cache.py
