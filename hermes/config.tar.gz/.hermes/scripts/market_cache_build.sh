#!/bin/bash
# Wrapper: build full market cache (IDX 951 + US 503 + Crypto 100)
# Jalankan via cron malam hari (misal 02:00 WIB) SEBELUM cron laporan pagi 08:00 WIB
set -e
cd /opt/data/market-cache
source .venv/bin/activate
python3 build_cache.py
